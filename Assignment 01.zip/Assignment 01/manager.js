
// Step 03 importing the books array.
import { books } from './book.js';

// Step 04 ===================(All the Functions)===========

// Function # 01
const function1 = () =>{
    const titles = books.filter(book => book.rating > 4.5).map(book => book.title);
    console.log("Books with rating higher than 4.5:",titles);
}


// Function # 02
const function2 = () => {
    for (let i = 0; i < books.length; i++) {
        const { id, title, author, rating, genre } = books[i];  // Destructuring the book object
        console.log(`Book ID ===> ${id}`);
        console.log(`Book Title ===> ${title}`);
        console.log(`Book Author ===> ${author}`);
        console.log(`Book Rating ===> ${rating}`);
        console.log(`Book Genre ===> ${genre}`);
        console.log('--------------------------------------------');
    };
};



// Function # 03
const function3 = () =>{
    const titles1 = books.filter(book => book.genre == "Fiction").map(book => book.title);
    console.log("Books with genre Fiction ===> ",titles1);
}



//Function # 04
const function4 = () => {
    const authors = books.map(book => book.author);
    console.log(`Books Authors Name ====>`);
    authors.forEach(author => console.log(author));
    
    console.log(`===============\n`);
}

// Calling the Functions.
function1();
function2();
function3();
function4();

